from __future__ import print_function

import tensorflow as tf
from keras.backend.tensorflow_backend import set_session
config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.2
set_session(tf.Session(config=config))
import numpy as np
import scipy.io as scio
import os
import sys
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import StratifiedKFold
from keras.callbacks import EarlyStopping
tf.set_random_seed(1)
# Parameters To Be Tuned
learning_rate = 0.0001           # Learning rate
f_input_keep_prob = 1.0         # Input dropout
f_output_keep_prob = 0.7        # Output dropout
f_regularization_ratio = 1e-6    # Regularization ratio
f_biases = 0.1                  # Input/Output biases
n_hidden_units = 128            # Hidden Neurons
n_layer = 3                     # RNN cell layer number
n_batch_size = 32               # Batch size
n_classes = 6                   # Gesture Classes
n_valid_set_size = 675          # Valid set size
n_test_set_size = 675          # Test set size
training_iters = 10000           # Train Interation Upbound
epochs = 30 
mo_sel = [1,2,3,4,5,6,0,0,0]
# -------------------------------------------------------
# Parameters Fixed
T = 0                          # Each Gesture Frame
n_time_steps = T                # Time steps
V_bins = 20                     # Each VS Size 20*20*T
n_input_units = V_bins*V_bins   # Input Neurous

#############################################Load all VS
for n_itr in range(9,10+1):
    print('Loading Data...')
    train_data_ori = []
    train_label_ori = []
    test_data_ori= []
    test_label_ori = []

    # Load Train Set
    root_path = 'Evaluation/train/'
    accuracy_log_file_name = 'acc_room11_' + str(n_itr)
    cm_log_file_name = 'CM_room11_' + str(n_itr)
    with open(accuracy_log_file_name, 'w') as accuracy_log_file:
        for root, dirs, files in os.walk(root_path):
            for file in files:
                
                #if int(file.split('-')[4]) == 4:
                #    continue
                file_path = os.path.join(root,file)
                train_data_1 = scio.loadmat(file_path)['velocity_spectrum_ro'].tolist()
                # train_data_1 = scio.loadmat(file_path)['VS'].tolist()
                train_label_1 = int(file.split('-')[2])
                train_label_1 = mo_sel[train_label_1-1]
                location = int(file.split('-')[3])
                orientation = int(file.split('-')[4])

                # Discard Motion
                if (train_label_1 == 0):
                    continue

                # Normalization
                train_data_1_arr = np.array(train_data_1)
                train_data_1_max = np.concatenate((train_data_1_arr.max(axis=0),\
                    train_data_1_arr.max(axis=1)),axis=0).max(axis=0)
                train_data_1_min = np.concatenate((train_data_1_arr.min(axis=0),\
                    train_data_1_arr.min(axis=1)),axis=0).min(axis=0)
                if (len(np.where((train_data_1_max - train_data_1_min) == 0)[0]) > 0):
                    continue
                train_data_1_max_rep = np.tile(train_data_1_max,(train_data_1_arr.shape[0],\
                    train_data_1_arr.shape[1],1))
                train_data_1_min_rep = np.tile(train_data_1_min,(train_data_1_arr.shape[0],\
                    train_data_1_arr.shape[1],1))
                train_data_1_arr_nor = (train_data_1_arr - \
                    train_data_1_min_rep)/(train_data_1_max_rep - train_data_1_min_rep)
                # Save List
                train_data_ori.append(train_data_1_arr_nor.tolist())
                train_label_ori.append(train_label_1)
                if T < np.array(train_data_1).shape[2]:
                    T = np.array(train_data_1).shape[2]
                    n_time_steps = T

        print('Loaded train set of ' + str(len(train_label_ori)) + ' Samples with ' + \
            str(n_classes) + ' Classes')
        print('Train T: ' + str(T))

        # Load Test Set
        root_path = 'Evaluation/test/'
        for root, dirs, files in os.walk(root_path):
            for file in files:
                file_path = os.path.join(root, file)
                test_data_1 = scio.loadmat(file_path)['velocity_spectrum_ro'].tolist()
                # train_data_1 = scio.loadmat(file_path)['VS'].tolist()
                test_label_1 = int(file.split('-')[2])
                test_label_1 = mo_sel[test_label_1-1]
                location = int(file.split('-')[3])
                orientation = int(file.split('-')[4])

                # Discard Motion
                if (test_label_1 == 0):
                    continue

                # Normalization
                test_data_1_arr = np.array(test_data_1)
                test_data_1_max = np.concatenate((test_data_1_arr.max(axis=0), \
                                                   test_data_1_arr.max(axis=1)), axis=0).max(axis=0)
                test_data_1_min = np.concatenate((test_data_1_arr.min(axis=0), \
                                                   test_data_1_arr.min(axis=1)), axis=0).min(axis=0)
                if (len(np.where((test_data_1_max - test_data_1_min) == 0)[0]) > 0):
                    continue
                test_data_1_max_rep = np.tile(test_data_1_max, (test_data_1_arr.shape[0], \
                                                                  test_data_1_arr.shape[1], 1))
                test_data_1_min_rep = np.tile(test_data_1_min, (test_data_1_arr.shape[0], \
                                                                  test_data_1_arr.shape[1], 1))
                test_data_1_arr_nor = (test_data_1_arr - \
                                        test_data_1_min_rep) / (test_data_1_max_rep - test_data_1_min_rep)
                # Save List
                test_data_ori.append(test_data_1_arr_nor.tolist())
                test_label_ori.append(test_label_1)
                if T < np.array(test_data_1).shape[2]:
                    T = np.array(test_data_1).shape[2]
                    n_time_steps = T

        print('Loaded test set of ' + str(len(test_label_ori)) + ' Samples with ' + \
            str(n_classes) + ' Classes')
        print('Test T: ' + str(T))

        #############################################Format and split all VS
        print('Formatting Data...')
        # Zero-padding
        train_data_pad = []
        train_label_pad = train_label_ori
        for i in range(len(train_data_ori)):
            t = np.array(train_data_ori[i]).shape[2]
            train_data_pad.append(np.pad(train_data_ori[i] \
                , ((0,0),(0,0),(T - t,0)), 'constant', constant_values = 0).tolist())
        test_data_pad = []
        test_label_pad = test_label_ori
        for i in range(len(test_data_ori)):
            t = np.array(test_data_ori[i]).shape[2]
            test_data_pad.append(np.pad(test_data_ori[i] \
                , ((0,0),(0,0),(T - t,0)), 'constant', constant_values = 0).tolist())

        # Convert to Ndarray
        train_data_all = np.array(train_data_pad)
        train_label_all = np.array(train_label_pad)
        test_data_all = np.array(test_data_pad)
        test_label_all = np.array(test_label_pad)

        # One-hot Encoding
        train_label_all = np.eye(np.max(train_label_all))[train_label_all-1]
        test_label_all = np.eye(np.max(test_label_all))[test_label_all-1]

        # Specify Train/Test Set
        # [train_data, test_data, train_label, test_label] = train_test_split(train_data_all,train_label_all,test_size=0.1,random_state=42)
        train_data = train_data_all
        train_label = train_label_all
        test_data = test_data_all
        test_label = test_label_all

        # Swap Axes
        train_data = np.swapaxes(np.swapaxes(train_data, 1, 3), 2, 3)
        train_data = np.expand_dims(train_data, axis=-1)
        test_data = np.swapaxes(np.swapaxes(test_data, 1, 3), 2, 3)
        test_data = np.expand_dims(test_data, axis=-1)

        #############################################Train, Validate And Test
        import keras
        from keras.models import Model, Sequential
        from keras.layers import Input, Dense, TimeDistributed, Flatten, Reshape, Permute, Dropout
        from keras.layers import LSTM, GRU
        from keras.layers import Conv2D, MaxPooling2D

        # 3D input.
        input_shape = (V_bins,V_bins,1)
        cnn = Sequential()
        cnn.add(Conv2D(16, kernel_size=(5,5), activation='relu',input_shape=input_shape))
        cnn.add(MaxPooling2D(pool_size=(2,2)))#16
        cnn.add(Flatten())
        cnn.add(Dense(64,activation='relu'))#64
        cnn.add(Dropout(0.5))
        cnn.add(Dense(64,activation='relu'))#64

        # Model Definition
        model = Sequential()
        model.add(TimeDistributed(cnn,input_shape=(T,V_bins,V_bins,1)))
        model.add(GRU(n_hidden_units))
        model.add(Dropout(0.2))
        model.add(Dense(n_classes, activation='softmax'))
        print(model.summary())
        model.compile(loss='categorical_crossentropy',
                    optimizer='rmsprop',
                    metrics=['accuracy'])

        # Training...
        model.fit(train_data, train_label,
                batch_size=n_batch_size,
                epochs=epochs,
                verbose=1,
                validation_split=0.1, shuffle=True)

        # Testing...
        scores = model.evaluate(test_data, test_label, verbose=0)
        test_label_predict = model.predict(test_data)
        test_label_predict = np.argmax(test_label_predict, axis = -1)+1
        test_label = np.argmax(test_label,axis=-1)+1
        cm = confusion_matrix(test_label, test_label_predict)
        print(cm)
        cm = cm.astype('float')/cm.sum(axis=1)[:, np.newaxis]
        print(cm)
        print('Test loss:', scores[0])
        print('Test accuracy:', scores[1])

        # Save Results to File
        np.savetxt(cm_log_file_name,cm)
        accuracy_log_file.write('Test loss:'+str(scores[0]))
        accuracy_log_file.write('Test accuracy:'+str(scores[1]))
        accuracy_log_file.close()

        # Save model to file
        print("Saving model to disk \n")
        mp = "./bvp_model.h5"
        model.save(mp)

